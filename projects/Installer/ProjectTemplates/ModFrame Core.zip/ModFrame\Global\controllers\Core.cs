﻿using Microsoft.AspNetCore.Mvc;

//Note: allows you to add global controllers for any global action fitler requirements etc.
public partial class MyController : Controller
{       
}
