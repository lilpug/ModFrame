﻿//Gulp plugin extensions
var gulp = require('gulp');
var concat = require("gulp-concat");
var cssmin = require("gulp-cssmin");
var uglify = require("gulp-uglify");
var less = require('gulp-less');
var sass = require('gulp-sass');

var path = require("path");
var newer = require("gulp-newer");
var gulpif = require('gulp-if');
var filter = require('gulp-filter');

//Processes the concatenation and minification of JS or CSS deppending on which is supplied 
function CoreConAndMin(isDebug, fileLocations, compiledBaseLocation, extensionType, extraCompiled)
{   
    //Checks if the fileLocations is looking for css files
    if (fileLocations.indexOf(".css") >= -1)
    {
        //Adds the extra support for less and sass files if its css concatenation and minification
        fileLocations = [fileLocations, fileLocations.replace(".css", ".less"), fileLocations.replace(".css", ".scss")];
    }

    //Creates filters to allow us to work specifically only with less and scss files if its in the css processing
    var sassFilter = filter('**/*.scss', { restore: true });    
    var lessFilter = filter('**/*.less', { restore: true });
    
    //Checks if the field has been supplied if not makes it an empty string
    if (extraCompiled == undefined)
    {
        extraCompiled = "";
    }

    gulp.src(fileLocations)
        //If the cached file list is not different then check if anything has changed in the files before pushing them through
        .pipe(newer(path.join(compiledBaseLocation, extraCompiled, extensionType, 'min.' + extensionType)))
        
        //Processes the sass section if any sass files
        .pipe(sassFilter)
        .pipe(sass())
        .pipe(sassFilter.restore)

        //Processes the less section if any less files
        .pipe(lessFilter)
        .pipe(less())
        .pipe(lessFilter.restore)                

        //Adds the files all together
        .pipe(concat('min.' + extensionType))

        //Checks if its js and uglifys it if so
        .pipe(gulpif((isDebug == false && extensionType == "js"), uglify()))

        //Checks if its css and minifys it if so
        .pipe(gulpif((isDebug == false && extensionType == "css"), cssmin()))

        //Outputs it to the destination
        .pipe(gulp.dest(path.join(compiledBaseLocation, extensionType, extraCompiled)));
}

// Exporting the plugins main function
module.exports = CoreConAndMin;