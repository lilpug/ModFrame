Author: David Whitehead
GitHub Repository: https://github.com/lilpug/modframe
Documentation Link: https://github.com/lilpug/modframe/wiki
License Link: https://raw.githubusercontent.com/lilpug/ModFrame/master/LICENSE

Note: This file can be deleted as its only containing information which might be helpful to get started.